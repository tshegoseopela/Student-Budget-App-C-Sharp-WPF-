﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.IO;
//all the libraries that will be implemented

namespace Tshegofatso_Seopela_20110597_POE
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {

        //declaration of variables
        public double income;
        public double estimatedTax;
        public double groceries;
        public double water_lights;
        public double travel_costs;
        public double cell_phone;
        public double other;

        //variable for the monthly rental amount
        public double monthlyRental;

        //variables for purchasing property
        public double purchase_priceB;
        public double depositB;
        public double interestRateB;
        public double numberMonthsB;

        public double purchase_priceV;
        public double depositV;
        public double interestRateV;
        public double numberMonthsV;
        public double insurancePremium;

        //variables for saving account
        public double futureValue;
        public double numberMonthsS;
        public double interestRateS;

        //repayment variables
        public double homeLoan;
        public double vehicleLoan;
        public double totalExpenses;

        //delegate for the static method
        public delegate double delNotification(double x , double y);

        public MainWindow()
        {
            InitializeComponent();

            //populating the combo box with two items
            cmbOptions.Items.Add("Renting");
            cmbOptions.Items.Add("Buying");

        }

        //static method that will check if the user is eligible for a loan
        public static double loanNotification(double x,double y)
        {
            MessageBox.Show("Since the monthly loan repayment is one third more than " +
                                       "your gross income, you are not eligible for a loan");
            return x;
        }

        public void Button_Click(object sender, RoutedEventArgs e)
        {
            //creating an instance of the generic collection <List>            
            List <double> budgetList;
            budgetList = new List<double>();

            //allowing the user to enter data 
            income = Convert.ToDouble(txtIncome.Text);
            estimatedTax = Convert.ToDouble(txtTax.Text);
            groceries = Convert.ToDouble(txtGroceries.Text);
            water_lights = Convert.ToDouble(txtWaterLights.Text);
            travel_costs = Convert.ToDouble(txtTravel.Text);
            cell_phone = Convert.ToDouble(txtCellPhone.Text);
            other = Convert.ToDouble(txtOther.Text);

            futureValue = Convert.ToDouble(txtFutureValue.Text);
            interestRateS = Convert.ToDouble(txtInterestRateS.Text);
            numberMonthsS = Convert.ToDouble(txtMonthsS.Text);

            //instantiating an instance of the delegate
            delNotification delNotification = new delNotification(loanNotification);

            budgetList.Add(income);
            budgetList.Add(estimatedTax);
            budgetList.Add(groceries);
            budgetList.Add(water_lights);
            budgetList.Add(travel_costs);
            budgetList.Add(cell_phone);
            budgetList.Add(other);
            
            budgetList.Add(futureValue);
            budgetList.Add(interestRateS);
            budgetList.Add(numberMonthsS);

            budgetList.Add(homeLoan);
            budgetList.Add(vehicleLoan);

            budgetList.Add(totalExpenses);

            //savings calculation
            double savings = futureValue / (1 + (interestRateS * numberMonthsS));
            budgetList.Add(savings);

            //calculating the total expenditures
            double totalExpenditure = groceries + water_lights + travel_costs + cell_phone + other;

            //writing all the expenses into a textfile
            StreamWriter file = new StreamWriter("Expenses.txt");
            file.Write(groceries);
            file.Write(water_lights);
            file.Write(travel_costs);
            file.Write(cell_phone);
            file.Write(other);
            file.Write(totalExpenditure);
            file.Close();
            MessageBox.Show("Monthly expenditures added to textfile :)");

            //calculating the total repayment amount from the vehicle and home loan
            double paramter = ((income - totalExpenses) / 4) * 3;

            //if the user decides to rent and not purchase a vehicle
            if ((cmbOptions.SelectedItem.ToString() == "Renting") && (radNoVehicle.IsChecked == true))
            {
                //allowing the user to enter data 
                monthlyRental = Convert.ToDouble(txtMonthlyRental.Text);
                budgetList.Add(monthlyRental);

                //displaying all the data
                MessageBox.Show("-----BUDGET APPLICATION-----" + "\n" +
                                "-----------------------------" + "\n" +
                                "Gross Monthly Income: R" + income.ToString() + "\n" +
                                "Estimated monthly Tax Deductions: R" + estimatedTax.ToString() + "\n" +
                                "***Monthly expenditure on: " + "\n" +
                                "1.Groceries R" + groceries.ToString() + "\n" +
                                "2.Water and Lights R" + water_lights.ToString() + "\n" +
                                "3.Travel Costs R" + travel_costs.ToString() + "\n" +
                                "4.Cell Phone R" + cell_phone.ToString() + "\n" +
                                "5.Other R" + other.ToString() + "\n" +
                                "Total monthly expenditure: R" + totalExpenditure + "\n" +
                                "------------------------------" + "\n" +
                                "~~~RENTING~~~" + "\n" +
                                "Monthly Rental Amount R" + monthlyRental.ToString() + "\n" +
                                "-------------------------------" + "\n" +
                                "~~~SAVINGS~~~" + "\n" +
                                "Savings Account" + "\n" +
                                "Future Value: R" + futureValue + "\n" +
                                "Interest Rate: " + interestRateS + "%" + "\n" +
                                "Number of Months: " + numberMonthsS + "\n" +
                                "You will need to save R" + savings.ToString() + " on a monthly basis" + "\n" +
                                "------------------------------");
                //if the user decides to rent and purchase a vehicle
            }else if ((cmbOptions.SelectedItem.ToString() == "Renting") && (radYesVehicle.IsChecked == true))
            {
                //allowing the user to enter data 
                monthlyRental = Convert.ToDouble(txtMonthlyRental.Text);

                purchase_priceV = Convert.ToDouble(txtPriceV.Text);
                depositV = Convert.ToDouble(txtDepositV.Text);
                interestRateV = Convert.ToDouble(txtInterestV.Text);
                numberMonthsV = Convert.ToDouble(txtMonthsV.Text);
                insurancePremium = Convert.ToDouble(txtInsuranceV.Text);

                budgetList.Add(monthlyRental);

                budgetList.Add(purchase_priceV);
                budgetList.Add(depositV);
                budgetList.Add(interestRateV);
                budgetList.Add(numberMonthsV);
                budgetList.Add(insurancePremium);

                //recalling the monthly repayment method for the vehicle and the property
                repaymentVehicle(purchase_priceV, depositV, interestRateV, numberMonthsV, insurancePremium);

                //displaying all the data
                MessageBox.Show("-----BUDGET APPLICATION-----" + "\n" +
                                "-----------------------------" + "\n" +
                              "Gross Monthly Income: R" + income.ToString() + "\n" +
                              "Estimated monthly Tax Deductions: R" + estimatedTax.ToString() + "\n" +
                              "***Monthly expenditure on: " + "\n" +
                              "1.Groceries R" + groceries.ToString() + "\n" +
                              "2.Water and Lights R" + water_lights.ToString() + "\n" +
                              "3.Travel Costs R" + travel_costs.ToString() + "\n" +
                              "4.Cell Phone R" + cell_phone.ToString() + "\n" +
                              "5.Other R" + other.ToString() + "\n" +
                               "Total monthly expenditure: R" + totalExpenditure + "\n" +
                              "------------------------------" + "\n" +
                              "~~~Rental~~~" + "\n" +
                              "Monthly Rental Amount R" + monthlyRental.ToString() + "\n" +
                              "-------------------------------" + "\n" +
                              "~~~Vehicle~~~" + "\n" +
                              "Purchase Price: R" + purchase_priceV.ToString() + "\n" +
                              "Deposit: R" + depositV.ToString() + "\n" +
                              "Interest Rate: " + interestRateV.ToString() + "\n" +
                              "Number of Months: " + numberMonthsV.ToString() + "\n" +
                              "Insurance Premium: R" + insurancePremium.ToString() + "\n" +
                              "Total repayment: R" + vehicleLoan.ToString() + "\n" +
                              "-----------------------------------" + "\n" +
                              "~~~SAVINGS~~~" + "\n" +
                              "Savings Account" + "\n" +
                              "Future Value: R" + futureValue + "\n" +
                               "Interest Rate: " + interestRateS + "%" + "\n" +
                               "Number of Months: " + numberMonthsS + "\n" +
                              "You will need to save R" + savings.ToString() + " on a monthly basis") ;

                //delegate to see if you qualify for the loans
                if (totalExpenses > paramter)
                {
                    delNotification.Invoke(0, vehicleLoan);
                }

            }  //if the user decides to purchase a home and not purchase a vehicle
            else if((cmbOptions.SelectedItem.ToString() == "Buying") && (radNoVehicle.IsChecked == true))
            {
                //allowing the user to enter data 
                purchase_priceB = Convert.ToDouble(txtPriceP.Text);
                depositB = Convert.ToDouble(txtDepositP.Text);
                interestRateB = Convert.ToDouble(txtInterestRateP.Text);
                numberMonthsB = Convert.ToDouble(txtMonthsP.Text);

                budgetList.Add(purchase_priceB);
                budgetList.Add(depositB);
                budgetList.Add(interestRateB);
                budgetList.Add(numberMonthsB);                

                //recalling the property home loan calculation
                repaymentProperty(purchase_priceB, depositB, interestRateB, numberMonthsB);

                //delegate to see if you qualify for the loans
                

                //displaying all the data
                MessageBox.Show("-----BUDGET APPLICATION-----" + "\n" +
                              "-----------------------------" + "\n" +
                              "Gross Monthly Income: R" + income.ToString() + "\n" +
                              "Estimated monthly Tax Deductions: R" + estimatedTax.ToString() + "\n" +
                              "***Monthly expenditure on: " + "\n" +
                              "1.Groceries R" + groceries.ToString() + "\n" +
                              "2.Water and Lights R" + water_lights.ToString() + "\n" +
                              "3.Travel Costs R" + travel_costs.ToString() + "\n" +
                              "4.Cell Phone R" + cell_phone.ToString() + "\n" +
                              "5.Other R" + other.ToString() + "\n" +
                               "Total monthly expenditure: R" + totalExpenditure + "\n" +
                              "----------------------------" + "\n" +
                              "~~~BUYING PROPERTY~~~" + "\n" +
                              "Purchase Price: R" + purchase_priceB.ToString() + "\n" +
                              "Deposit: R" + depositB.ToString() + "\n" +
                              "Interest Rate: " + interestRateB.ToString() + "\n" +
                              "Number of Months: " + numberMonthsB.ToString() + "\n" +
                              "Total repayment: R" + homeLoan.ToString() + "\n" +
                              "-----------------------------------" + "\n" +
                              "~~~SAVINGS~~~" + "\n" +
                              "Savings Account" + "\n" +
                              "Future Value: R" + futureValue + "\n" +
                              "Interest Rate: " + interestRateS + "%" + "\n" +
                              "Number of Months: " + numberMonthsS + "\n" +
                              "You will need to save R" + savings.ToString() + " on a monthly basis");

                //delegate to see if you qualify for the loans
                if (totalExpenses > paramter)
                {
                    delNotification.Invoke(homeLoan, 0);
                }

            }  //if the user decides to purchase a vehicle and property
            else if((cmbOptions.SelectedItem.ToString() == "Buying") && (radYesVehicle.IsChecked == true))
            {
                //allowing the user to enter data 
                purchase_priceB = Convert.ToDouble(txtPriceP.Text);
                depositB = Convert.ToDouble(txtDepositP.Text);
                interestRateB = Convert.ToDouble(txtInterestRateP.Text);
                numberMonthsB = Convert.ToDouble(txtMonthsP.Text);

                purchase_priceV = Convert.ToDouble(txtPriceV.Text);
                depositV = Convert.ToDouble(txtDepositV.Text);
                interestRateV = Convert.ToDouble(txtInterestV.Text);
                numberMonthsV = Convert.ToDouble(txtMonthsV.Text);
                insurancePremium = Convert.ToDouble(txtInsuranceV.Text);

                budgetList.Add(purchase_priceB);
                budgetList.Add(depositB);
                budgetList.Add(interestRateB);
                budgetList.Add(numberMonthsB);

                budgetList.Add(purchase_priceV);
                budgetList.Add(depositV);
                budgetList.Add(interestRateV);
                budgetList.Add(numberMonthsV);
                budgetList.Add(insurancePremium);

                //recalling the monthly repayment method for the vehicle and the property
                repaymentVehicle(purchase_priceV, depositV, interestRateV, numberMonthsV, insurancePremium);
                repaymentProperty(purchase_priceB, depositB, interestRateB, numberMonthsB);

                //displaying all the data
                MessageBox.Show("-----BUDGET APPLICATION-----" + "\n" +
                              "-----------------------------" + "\n" +
                              "Gross Monthly Income: R" + income.ToString() + "\n" +
                              "Estimated monthly Tax Deductions: R" + estimatedTax.ToString() + "\n" +
                              "***Monthly expenditure on: " + "\n" +
                              "1.Groceries R" + groceries.ToString() + "\n" +
                              "2.Water and Lights R" + water_lights.ToString() + "\n" +
                              "3.Travel Costs R" + travel_costs.ToString() + "\n" +
                              "4.Cell Phone R" + cell_phone.ToString() + "\n" +
                              "5.Other R" + other.ToString() + "\n" +
                              "Total monthly expenditure: R" + totalExpenditure + "\n" +
                              "----------------------------" + "\n" +
                              "~~~BUYING PROPERTY~~~" + "\n" +
                              "Purchase Price: R" + purchase_priceB.ToString() + "\n" +
                              "Deposit: R" + depositB.ToString() + "\n" +
                              "Interest Rate" + interestRateB.ToString() + "\n" +
                              "Number of Months" + numberMonthsB.ToString() + "\n" +
                              "Total repayment: R" + homeLoan.ToString() + "\n" +
                              "----------------------------" + "\n" +
                               "~~~Vehicle~~~" + "\n" +
                              "Purchase Price: R" + purchase_priceV.ToString() + "\n" +
                              "Deposit: R" + depositV.ToString() + "\n" +
                              "Interest Rate" + interestRateV.ToString() + "%" +"\n" +
                              "Number of Months" + numberMonthsV.ToString() + "\n" +
                              "Insurance Premium: R" + insurancePremium.ToString() + "\n" +
                              "Total repayment: R" + vehicleLoan.ToString() + "\n" +
                              "-----------------------------------" + "\n" +
                              "~~~SAVINGS~~~" + "\n" +
                              "Savings Account" + "\n" +
                              "Future Value: R" + futureValue + "\n" +
                               "Interest Rate: " + interestRateS + "%" + "\n" +
                               "Number of Months: " + numberMonthsS + "\n" +
                              "You will need to save R" + savings.ToString() + " on a monthly basis");

                //delegate to see if you qualify for the loans
                if (totalExpenses > paramter)
                {
                    delNotification.Invoke(homeLoan, vehicleLoan);
                }

            }
        }
        
        //hiding the purchasing components and disabling the components
        public void radNoVehicle_Checked(object sender, RoutedEventArgs e)
        {
            //hiding the components
            txtPriceV.Visibility = System.Windows.Visibility.Hidden;
            txtInterestV.Visibility = System.Windows.Visibility.Hidden;
            txtDepositV.Visibility = System.Windows.Visibility.Hidden;
            txtMonthsV.Visibility = System.Windows.Visibility.Hidden;
            txtInsuranceV.Visibility = System.Windows.Visibility.Hidden;

            lblDepositV.Visibility = System.Windows.Visibility.Hidden;
            lblPriceV.Visibility = System.Windows.Visibility.Hidden;
            lblMonths.Visibility = System.Windows.Visibility.Hidden;
            lblInsuranceV.Visibility = System.Windows.Visibility.Hidden;
            lblInterestRateV.Visibility = System.Windows.Visibility.Hidden;

        }

        //allowing the user to view and enter data for the vehicle purchase
        public void radYesVehicle_Checked(object sender, RoutedEventArgs e)
        {
            //variables for purchasing a vehicle
            txtPriceV.Visibility = System.Windows.Visibility.Visible;
            txtInterestV.Visibility = System.Windows.Visibility.Visible;
            txtDepositV.Visibility = System.Windows.Visibility.Visible;
            txtMonthsV.Visibility = System.Windows.Visibility.Visible;
            txtInsuranceV.Visibility = System.Windows.Visibility.Visible;

            lblDepositV.Visibility = System.Windows.Visibility.Visible;
            lblPriceV.Visibility = System.Windows.Visibility.Visible;
            lblMonths.Visibility = System.Windows.Visibility.Visible;
            lblInsuranceV.Visibility = System.Windows.Visibility.Visible;
        }

        //method that will calculate the monthly repayment for buying property and a vehicle
        public void repaymentVehicle(double price , double deposit , double interest , double months , double insurance)
        {
            double P = price - deposit;
            vehicleLoan = (P * (interest / months)) + insurance ;
        }

        //method that will calculate the monthly repayment for buying property and a vehicle
        public void repaymentProperty(double price, double deposit, double interest, double months)
        {
            double P = price - deposit;
            homeLoan = P * (interest / months);
        }

        //combo box that will allow the user to select between renting and buying property
        private void cmbOptions_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            //if statement that will hide and disable the buying components when "renting" is selected 
            if(cmbOptions.SelectedItem.ToString() == "Renting")
            {
                lblRental.Visibility = System.Windows.Visibility.Visible;
                txtMonthlyRental.Visibility = System.Windows.Visibility.Visible;

                txtPriceP.Visibility = System.Windows.Visibility.Hidden;
                txtDepositP.Visibility = System.Windows.Visibility.Hidden;
                txtInterestRateP.Visibility = System.Windows.Visibility.Hidden;
                txtMonthsP.Visibility = System.Windows.Visibility.Hidden;
                lblPriceP.Visibility = System.Windows.Visibility.Hidden;
                lblInterestP.Visibility = System.Windows.Visibility.Hidden;
                lblMonthsP.Visibility = System.Windows.Visibility.Hidden;
                lblDepositP.Visibility = System.Windows.Visibility.Hidden;

            } //if statement that will hide and disable the renting components when "buying" is selected 
            else if (cmbOptions.SelectedItem.ToString() == "Buying")
            {
                lblRental.Visibility = System.Windows.Visibility.Hidden;
                txtMonthlyRental.Visibility = System.Windows.Visibility.Hidden;

                txtPriceP.Visibility = System.Windows.Visibility.Visible;
                txtDepositP.Visibility = System.Windows.Visibility.Visible;
                txtInterestRateP.Visibility = System.Windows.Visibility.Visible;
                txtMonthsP.Visibility = System.Windows.Visibility.Visible;
                lblPriceP.Visibility = System.Windows.Visibility.Visible;
                lblInterestP.Visibility = System.Windows.Visibility.Visible;
                lblMonthsP.Visibility = System.Windows.Visibility.Visible;
                lblDepositP.Visibility = System.Windows.Visibility.Visible;
            }
        }

    }
}